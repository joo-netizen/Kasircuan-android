# Kasir Cuan Android APK

Project wrapper Android untuk file HTML Kasir Cuan menggunakan Capacitor. APK dibangun otomatis lewat GitHub Actions.

## Cara paling mudah dari HP
1. Download dan ekstrak ZIP ini.
2. Buat repository baru di GitHub bernama `kasir-cuan-android`.
3. Upload semua ISI folder ini ke repository (pastikan folder `.github/workflows` ikut ter-upload).
4. Buka tab **Actions** di repository. Jika diminta, aktifkan GitHub Actions.
5. Pilih workflow **Build Kasir Cuan APK**, lalu tekan **Run workflow**. Atau tunggu workflow otomatis berjalan setelah file di-push ke branch `main`.
6. Setelah workflow selesai hijau, buka hasil run tersebut, scroll ke **Artifacts**, lalu download `kasir-cuan-apk`.
7. Ekstrak file artifact ZIP dan instal `app-debug.apk` di Android. Jika diminta, izinkan instalasi dari sumber tersebut.

## Catatan
- Ini adalah APK debug untuk instalasi pribadi, bukan paket Google Play Store.
- Login dan sinkronisasi Supabase tetap memerlukan internet.
- Pastikan file `www/index.html` adalah versi HTML terbaru sebelum build ulang.
- Jangan memasukkan Supabase service-role/secret key ke aplikasi. Gunakan publishable/anon key saja.
